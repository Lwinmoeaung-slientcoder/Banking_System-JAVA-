package Banking;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.Scanner;

public class Banking_System {
	String username="admin";
	String password="admin";
	String user;
	String pwd;
	int count=0;
	int balance=0;
	String path="D:/balance.txt";
	int file_balance=0;
	boolean flag=true;
	File file=new File("D:/balance.txt");

	public Banking_System() throws IOException{
	
	login();
	choose();
	}
	
	//login 
	void login() throws IOException{
		Scanner sc=new Scanner(System.in);
		System.out.print("Username : ");
		user=sc.next();
		System.out.print("Password : ");
		pwd=sc.next();
	if(username.equals(user)&&password.equals(pwd)){
		if(file.exists()){
			System.out.println("Welocome : "+username);
		}
		else{
			FileWriter fileWriter = new FileWriter(path);
	        fileWriter.close();
			System.out.println("Welocome : "+username);
			}	
		}
	else{
		count=count+1;
		System.out.println(count);
		System.out.println("Username or password is Wrong..");
		if(count==3){
			System.out.println("Your account is locked!!!!");
			return;
		 }
		login();
		}
	}
	

	//choose
	void choose(){
		try{
			Scanner sc=new Scanner(System.in);
			System.out.print("1.Check Account ,");
			System.out.print(" 2.Money Withdraw ,");
			System.out.print(" 3.Money Deposit ,");
			System.out.print(" 4.Exit");
			int choose=sc.nextInt();
			switch(choose){
			case 1 : check_account(user);
				break;
			case 2 :Withdraw();
			break;
			case 3 :deposit();
			break;
			case 4 : return;
			default :
				System.out.println("Type only mentioned above!!!");
				choose();
			}
		}catch(Exception e){
			System.out.println("Type only Number");	
			System.out.println("Error :"+e);
			choose();
		}
	}
	
	//Check Balance
	void check_account(String user) throws IOException{
		reader();
		System.out.println("Account Name :"+ user);
		System.out.println("Your Balance is : "+ file_balance);
		choose();
	}
	
	//Money Withdraw
	void Withdraw() throws IOException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Type Ammount");
		int balance=sc.nextInt();	
		reader();
		if(file_balance<=0 || balance>file_balance){
			System.out.println("You haven't Enough money");
			choose();
		}
		else if(flag==true && file_balance>0){
				file_balance=file_balance-balance;
				writer(file_balance);
				choose();
		}else{
			System.out.println("You haven't Enough money");
			choose();
		}
	}
	
	//Deposit Money
	void deposit() throws IOException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Type Ammount");
		int balance=sc.nextInt();
		if(file.exists()){
			reader();	
			file_balance=file_balance+balance;
			writer(file_balance);
			choose();
		}else{
			writer(balance);
			choose();
		}		
	}
	
	//file Writer
	void writer(int b) throws IOException{
	   Charset UTF8 = Charset.forName("UTF-8");
        balance=b;
        FileWriter fileWriter = new FileWriter(path);
        fileWriter.append(balance+"");
        fileWriter.flush();
        fileWriter.close();
            System.out.println("Process is complete");
        }
	
	//File Reader
	void reader() throws IOException{
		 FileInputStream fis = new FileInputStream(path);
		    InputStreamReader input = new InputStreamReader(fis);
		    BufferedReader br = new BufferedReader(input);
		    String data;
		    String result = new String();

		    while ((data = br.readLine()) != null) {
		        result = data;
		    }
		  if(result.isEmpty()){
			  flag=false;
		  }else{
			  file_balance=Integer.parseInt(result);
		  }
	}

	public static void main(String[] args) throws IOException {
		new Banking_System();

	}
}
